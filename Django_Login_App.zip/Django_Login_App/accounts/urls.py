"""URL patterns for the accounts app."""

from django.urls import path
from . import views

urlpatterns = [
    path('register/',  views.register_view,  name='register'),
    path('login/',     views.login_view,     name='login'),
    path('logout/',    views.logout_view,    name='logout'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('profile/',   views.profile_view,   name='profile'),
    path('regex/',     views.regex_demo_view, name='regex_demo'),
]
